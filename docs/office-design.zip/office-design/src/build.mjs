// Builds the three office design prototypes and the comparison page.
// Run: node docs/office-design/src/build.mjs
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SRC = dirname(fileURLToPath(import.meta.url));
const OUT = join(SRC, "..");
const read = (f) => readFileSync(join(SRC, f), "utf8");
const content = JSON.parse(read("content.json"));

/* ------------------------------------------------------------------ */
/* Sample data, built from the real site content                       */
/* ------------------------------------------------------------------ */
const seed = (() => {
  const tours = content.tours.map((t) => {
    const n = Math.min(t.duration, 5);
    const days = Array.from({ length: n }, (_, i) => ({
      title: i === 0 ? `${t.transport === "By Air" ? "Fly" : "Drive"} from Islamabad to ${t.location}` : i === n - 1 && n > 1 ? "Return to Islamabad" : `Explore ${t.location}`,
      text: i === 0 ? "Meet the driver at 7 AM. Check in to the hotel in the evening." : i === n - 1 && n > 1 ? "Breakfast, then the drive home with stops for photos." : "Full day of sightseeing with the guide.",
      highlights: [],
    }));
    return {
      ...t,
      description: `A ${t.duration}-day ${t.transport.replace("By ", "").toLowerCase()} trip to ${t.location}, with hotel stays, a private driver, and time at the best viewpoints.`,
      image: `/images/tours/${t.code}.webp`, gallery: [`/images/tours/${t.code}-1.webp`, `/images/tours/${t.code}-2.webp`],
      days, included: ["Transport", "Hotel stay", "Driver and fuel", "Breakfast"], notIncluded: ["Lunch and dinner", "Entry tickets", "Personal expenses"],
      categories: /Couple/.test(t.name) ? ["Couple"] : /Family/.test(t.name) ? ["Family"] : ["Family", "Couple"], packageTypes: ["Deluxe", "Executive", "Luxury", "Ultra Luxury"],
    };
  });
  const places = content.places.map((p) => ({ ...p, banner: `/images/destinations/${p.slug}.webp`, sections: [
    { heading: "Overview", body: p.excerpt, image: "", highlights: [] },
    { heading: "Best time to visit", body: "May to October, when the roads are open and the valleys are green.", image: "", highlights: ["May to October", "Cool nights, bring a jacket"] },
    { heading: "Getting there", body: "By road from Islamabad, or by air where a flight is offered.", image: "", highlights: [] },
  ] }));
  const posts = content.posts.map((p) => ({ ...p, cover: `/images/blog/${p.slug}.webp`, sections: [
    { heading: "Introduction", body: p.excerpt, image: "", highlights: [] },
    { heading: "Plan your trip", body: "When to go, what to pack, and how to get there.", image: "", highlights: [] },
  ] }));
  const reviews = content.reviews.map((r) => ({ ...r, avatar: "" }));
  const slides = [
    { id: 1, image: "/images/slider/JeepSafari.webp", title: "Jeep Safari", rotation: -15, order: 1 },
    { id: 2, image: "/images/slider/NatureWildlife.webp", title: "Nature & Wildlife", rotation: -7, order: 2 },
    { id: 3, image: "/images/slider/Adventure.webp", title: "Adventure", rotation: 0, order: 3 },
    { id: 4, image: "/images/slider/Hiking.webp", title: "Hiking", rotation: 7, order: 4 },
  ];
  const site = {
    phoneDisplay: "+92 333 9981177", phoneE164: "923339981177", email: "info@travelwithmoeen.com",
    address: "Office # 3, 2nd Floor, Shalimar Plaza, F-10 Markaz, Islamabad",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Office+3+2nd+Floor+Shalimar+Plaza+F-10+Markaz+Islamabad",
    facebookUrl: "https://www.facebook.com/TravelwithMoeen", instagramUrl: "https://www.instagram.com/travelwithmoeen/",
    tiktokUrl: "https://www.tiktok.com/@travelwithmoeen", youtubeUrl: "https://www.youtube.com/@itsmoeen",
  };
  const R = (id, name, kind, status, at, phone, email, message, tour = "") => ({ id, name, kind, status, at, phone, email, message, tour });
  const requests = [
    R(1, "Ayesha Khan", "booking", "new", "2026-10-09T09:14:00+05:00", "0300 0000001", "", "We want to book this tour for 2 adults in the first week of November. Please confirm the hotel.", "5 Days Trip to Skardu (By Air) - Private Tours"),
    R(2, "Hamza Raza", "custom", "in_progress", "2026-10-08T18:02:00+05:00", "0321 0000002", "hamza@example.com", "Family of 5, Hunza and Khunjerab, 7 days in late October. Two children aged 6 and 9."),
    R(3, "Sana Malik", "booking", "new", "2026-10-08T13:20:00+05:00", "0312 0000003", "", "Ratti Gali for 4 people. Is the lake open after mid October?", "3 Days Trip to Ratti Gali Lake"),
    R(4, "Bilal Ahmed", "contact", "closed", "2026-10-07T11:40:00+05:00", "", "bilal@example.com", "Do you offer tours to Malam Jabba in winter for skiing?"),
    R(5, "Mariam Shah", "custom", "new", "2026-10-07T08:05:00+05:00", "0333 0000005", "mariam@example.com", "Honeymoon trip, 6 days, Skardu and Shangrila. Luxury hotels please."),
    R(6, "Usman Tariq", "booking", "in_progress", "2026-10-06T21:15:00+05:00", "0345 0000006", "", "Booking for our office group of 12 people. Need a Coaster.", "4 Days By Road Trip to Naran Kaghan and Babusar Top"),
    R(7, "Fatima Noor", "contact", "closed", "2026-10-05T16:30:00+05:00", "", "fatima@example.com", "Thank you for the Kalash trip. The guide was excellent."),
    R(8, "Ali Hassan", "custom", "in_progress", "2026-10-05T10:10:00+05:00", "0301 0000008", "", "Fairy Meadows with parents in their sixties. Is the jeep track safe?"),
    R(9, "Zainab Qureshi", "booking", "closed", "2026-10-03T12:00:00+05:00", "0322 0000009", "zainab@example.com", "Booked and paid. Please send the itinerary PDF.", "6 Days By Road Trip to Hunza Valley and Khunjerab Pass (Couple)"),
    R(10, "Omar Farooq", "contact", "in_progress", "2026-10-02T19:45:00+05:00", "0300 0000010", "", "Can I pay in two parts?"),
    R(11, "Hira Javed", "custom", "closed", "2026-10-01T09:30:00+05:00", "", "hira@example.com", "Neelum Valley, 3 days, student group of 20."),
    R(12, "Danish Iqbal", "booking", "closed", "2026-09-29T17:05:00+05:00", "0315 0000012", "", "Need pickup from Lahore for this tour.", "7 Days By Road Trip to Skardu and Deosai National Park"),
  ];
  const ratePlaces = [["Skardu Valley", 9000], ["Hunza Valley", 8500], ["Naran Kaghan", 7000], ["Swat Valley", 6500], ["Neelum Valley", 6000]];
  const grades = [["Deluxe", 1], ["Executive", 1.5], ["Luxury", 2], ["Ultra Luxury", 3]];
  const round = (n) => Math.round(n / 500) * 500;
  let hid = 0;
  const hotels = ratePlaces.flatMap(([p, base]) => ["Islamabad", "Lahore"].flatMap((s) => grades.map(([g, m]) => ({ id: ++hid, place: p, start: s, grade: g, twin: round(base * m), triple: round(base * m * 1.3), hotel: `Sample ${g.toLowerCase()} hotel, ${p.split(" ")[0]}`, offered: !(g === "Ultra Luxury" && p === "Neelum Valley") }))));
  let vid = 0;
  const vehicles = ratePlaces.flatMap(([p]) => [["Gli Car", 10000, 6000, 1200, 3], ["Prado", 22000, 9000, 1200, 6], ["Hiace", 18000, 8000, 1500, 12], ["Coaster", 28000, 11000, 2000, 22]].map(([v, r, f, t, s]) => ({ id: ++vid, place: p, start: "Islamabad", vehicle: v, rent: r, fuel: f, toll: t, seats: s, live: !(v === "Coaster" && p === "Neelum Valley") })));
  const jeeps = [["Shigar and Cold Desert", "Skardu Valley", "Road", 8000], ["Deosai Plains", "Skardu Valley", "Road", 18000], ["Basho Valley", "Skardu Valley", "Air", 12000], ["Khunjerab Pass", "Hunza Valley", "Road", 14000], ["Hopper Glacier", "Hunza Valley", "Air", 7000], ["Lake Saif-ul-Malook", "Naran Kaghan", "Road", 6000], ["Fairy Meadows track", "Naran Kaghan", "Road", 15000], ["Mahodand Lake", "Swat Valley", "Road", 9000]].map(([label, place, mode, amount], i) => ({ id: i + 1, label, place, mode, amount, live: i !== 4 }));
  const backups = Array.from({ length: 8 }, (_, i) => { const d = new Date(Date.UTC(2026, 9, 9 - i, 0, 0, 12)); const at = d.toISOString(); return { name: `backups/preview-${at.replace(/[:.]/g, "-")}.json`, at, size: 1468006 - i * 9300, manual: false }; });
  const users = [
    { id: 1, email: "moeen@travelwithmoeen.com", role: "owner", lastSeen: "2026-10-09T09:20:00+05:00" },
    { id: 2, email: "manager@travelwithmoeen.com", role: "manager", lastSeen: "2026-10-08T17:40:00+05:00" },
    { id: 3, email: "editor@travelwithmoeen.com", role: "editor", lastSeen: "2026-10-07T11:00:00+05:00" },
    { id: 4, email: "sana.editor@travelwithmoeen.com", role: "editor", lastSeen: "" },
  ];
  return { tours, places, posts, photos: content.photos, reviews, slides, site, requests, hotels, vehicles, jeeps, backups, users, season: 20,
    air: { islamabadTicket: 48000, lahoreAdd: 15000, karachiAdd: 30000, welcomePack: 2500, entry: 1500, infantExtra: 5000, sticker: 1000 } };
})();

/* ------------------------------------------------------------------ */
/* Tokens per version and theme                                        */
/* ------------------------------------------------------------------ */
const hc = (primary, extra = {}) => ({
  canvas: "#ffffff", surface: "#ffffff", "surface-2": "#efefef", "surface-3": "#dcdcdc", "surface-hover": "#e4e4e4", selected: "#fff2b3", "field-bg": "#ffffff",
  border: "#000000", "border-strong": "#000000", "card-line": "#000000", text: "#000000", "text-2": "#1a1a1a", "text-3": "#2e2e2e", link: "#0030a0",
  primary, "primary-hover": "#000000", "on-primary": "#ffffff", "primary-soft": "#e3ebff", "primary-soft-text": "#001a57", focus: "#000000",
  danger: "#a00000", "on-danger": "#ffffff", "danger-soft": "#ffecec", "danger-text": "#8a0000",
  "success-soft": "#e6f7ea", "success-text": "#004d1a", "warning-soft": "#fff1cc", "warning-text": "#5c3100", "info-soft": "#e3ebff", "info-text": "#001a57",
  accent: "#ffd400", "accent-soft": "#ffe880", "accent-text": "#000000", "accent-ink": "#000000",
  "nav-bg": "#000000", "nav-text": "#ffffff", "nav-muted": "#e6e6e6", "nav-hover": "#2b2b2b", "nav-active": "#ffd400", "nav-active-text": "#000000", "nav-indicator": "#ffffff", "nav-line": "#ffffff",
  "logo-bg": "#ffd400", "logo-ink": "#000000", "topbar-bg": "#ffffff", "warning-dot": "#000000",
  overlay: "rgba(0,0,0,.75)", "shadow-1": "none", "shadow-2": "none", "shadow-3": "0 0 0 3px #000", ...extra,
});

const VERSIONS = [
  {
    id: "harbor", file: "1-harbor.html", name: "Harbor", tagline: "Enterprise clarity", num: 1,
    fonts: "family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500",
    shell: "side", list: "table", edit: "page", requests: "table", palette: false, hero: false,
    inspiration: "IBM Carbon and Atlassian",
    summary: "A dense, square, data-first office for people who work in tables all day. Dark navy UI shell, flat white tiles on gray, filled fields with a bottom rule.",
    traits: ["Dark navy side navigation and header form one UI shell.", "Every list is a sortable-looking data table; rows link to full edit pages with breadcrumbs.", "Square corners, no shadows, a 3 px blue top rule on stats and save bar.", "Carbon-style filled fields with a bottom border and small labels.", "Requests open as their own page; good for long messages and printing."],
    principles: [["Data first", "Show the most rows that stay readable. Tables beat cards."], ["One page, one job", "Edit on a full page with a breadcrumb back to the list."], ["Quiet chrome", "The dark shell frames the work; content stays on white."], ["Predictable", "Same table, same actions, same place on every list."]],
    fontNote: "IBM Plex Sans, with light 300 for big numbers and 400 for headings. IBM Plex Mono for codes and file names.",
    shapeNote: "Corners are 0 to 4 px. Depth comes from the gray canvas against white tiles, not from shadows.",
    type: [["Page title · 400 28/36", "font:400 28px/36px var(--font)", "Rates and quotes"], ["Stat · 300 34/40", "font:300 34px/40px var(--font)", "Rs 140,400"], ["Card title · 600 16/24", "font:600 16px/24px var(--font)", "Day plan"], ["Body · 400 14/20", "font:400 14px/20px var(--font)", "The tour page and its day plan will be removed from the website."], ["Label · 400 12.5/16", "font:400 12.5px/16px var(--font);color:var(--text-2);letter-spacing:.02em", "Twin room rate"], ["Code · Plex Mono 13", "font:400 13px/20px var(--font-mono)", "backups/preview-2026-10-09.json"]],
    patterns: [["Navigation", "Fixed dark sidebar on desktop; drawer from a menu button under 960 px."], ["Lists", "Data tables with search and filters; tables turn into cards on phones."], ["Editing", "Full page with breadcrumb and a sticky save bar."], ["Requests", "Table with status tabs; a row opens a detail page."], ["Deletes", "Confirm dialog for tours, logins, and roles; undo toast for photos, reviews, slides, and requests."]],
    tokens: {
      light: { canvas: "#f4f4f4", surface: "#ffffff", "surface-2": "#f4f4f4", "surface-3": "#e0e0e0", "surface-hover": "#e8e8e8", selected: "#e5eefc", "field-bg": "#f4f4f4", border: "#e0e0e0", "border-strong": "#6f6f6f", "card-line": "#e0e0e0", text: "#161616", "text-2": "#454545", "text-3": "#5c5c5c", link: "#0043ce",
        primary: "#0f62fe", "primary-hover": "#0050e6", "on-primary": "#ffffff", "primary-soft": "#edf5ff", "primary-soft-text": "#0043ce", focus: "#0f62fe",
        danger: "#da1e28", "on-danger": "#ffffff", "danger-soft": "#fff1f1", "danger-text": "#a2191f", "success-soft": "#defbe6", "success-text": "#0e6027", "warning-soft": "#fcf4d6", "warning-text": "#684e00", "info-soft": "#edf5ff", "info-text": "#0043ce",
        accent: "#f1c21b", "accent-soft": "#fcf4d6", "accent-text": "#5a4200", "accent-ink": "#161616",
        "nav-bg": "#0b2545", "nav-text": "#e8edf4", "nav-muted": "#a9b8cc", "nav-hover": "#13315c", "nav-active": "#1d4477", "nav-active-text": "#ffffff", "nav-indicator": "#f1c21b", "nav-line": "#1f3b63",
        "logo-bg": "#f1c21b", "logo-ink": "#161616", "topbar-bg": "#0b2545", "warning-dot": "#b28600", overlay: "rgba(22,22,22,.5)",
        "shadow-1": "none", "shadow-2": "0 2px 6px rgba(0,0,0,.2)", "shadow-3": "0 4px 16px rgba(0,0,0,.24)" },
      dark: { canvas: "#161616", surface: "#262626", "surface-2": "#2e2e2e", "surface-3": "#393939", "surface-hover": "#333333", selected: "#1c2a44", "field-bg": "#2e2e2e", border: "#393939", "border-strong": "#8d8d8d", "card-line": "#393939", text: "#f4f4f4", "text-2": "#c6c6c6", "text-3": "#a8a8a8", link: "#78a9ff",
        primary: "#78a9ff", "primary-hover": "#a6c8ff", "on-primary": "#161616", "primary-soft": "#1c2a44", "primary-soft-text": "#a6c8ff", focus: "#ffffff",
        danger: "#ff8389", "on-danger": "#161616", "danger-soft": "#3a1a1c", "danger-text": "#ffb3b8", "success-soft": "#0e2a17", "success-text": "#6fdc8c", "warning-soft": "#2e2500", "warning-text": "#f1c21b", "info-soft": "#1c2a44", "info-text": "#a6c8ff",
        accent: "#f1c21b", "accent-soft": "#2e2500", "accent-text": "#fddc69", "accent-ink": "#161616",
        "nav-bg": "#0b1a30", "nav-text": "#dde4ee", "nav-muted": "#95a3b8", "nav-hover": "#12243f", "nav-active": "#1d3557", "nav-active-text": "#ffffff", "nav-indicator": "#f1c21b", "nav-line": "#1d2f4a",
        "logo-bg": "#f1c21b", "logo-ink": "#161616", "topbar-bg": "#0b1a30", "warning-dot": "#f1c21b", overlay: "rgba(0,0,0,.65)",
        "shadow-1": "none", "shadow-2": "0 2px 6px rgba(0,0,0,.5)", "shadow-3": "0 6px 20px rgba(0,0,0,.6)" },
      hc: hc("#00338a", { "topbar-bg": "#000000" }),
    },
  },
  {
    id: "meadow", file: "2-meadow.html", name: "Meadow", tagline: "Calm workspace", num: 2,
    fonts: "family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500",
    shell: "side", list: "rows", edit: "drawer", requests: "inbox", palette: true, hero: false,
    inspiration: "Linear, Notion, and Apple's Human Interface Guidelines",
    summary: "A quiet, light workspace. A pale sidebar, soft cards, segmented tabs, a Ctrl K command bar, and editors that slide in from the right so the list stays in view.",
    traits: ["Light sidebar that blends with the page; the current page is a white pill.", "Ctrl K (or the search bar) jumps to any page, tour, place, post, or request.", "Lists are rows with thumbnails; editing opens in a drawer beside the list.", "Requests work like an email inbox: list on the left, message on the right.", "Teal brand color, 8 to 16 px corners, soft shadows, Inter type."],
    principles: [["Stay in flow", "Edit without leaving the list. Close the drawer and you are where you were."], ["Keyboard first", "Every page and record is two keystrokes away with Ctrl K."], ["Calm by default", "Low-contrast chrome, strong contrast where it matters: text, fields, focus."], ["Show, don't decorate", "Thumbnails help you recognise a row; nothing else is decoration."]],
    fontNote: "Inter with stylistic sets for clearer 1, l, and I. Tight letter spacing on headings. JetBrains Mono for codes.",
    shapeNote: "8 px controls, 12 px cards, 16 px dialogs. Soft two-layer shadows.",
    type: [["Page title · 600 24/32", "font:600 24px/32px var(--font);letter-spacing:-.02em", "Requests"], ["Section · 600 16/24", "font:600 16px/24px var(--font)", "Latest requests"], ["Body · 400 14/20", "font:400 14px/20px var(--font)", "Family of 5, Hunza and Khunjerab, 7 days in late October."], ["Label · 500 14/20", "font:500 14px/20px var(--font)", "Twin room rate"], ["Nav · 500 13.5", "font:500 13.5px/20px var(--font)", "Rates and quotes"], ["Code · JetBrains Mono 13", "font:400 13px/20px var(--font-mono)", "backups/preview-2026-10-09.json"]],
    patterns: [["Navigation", "Light sidebar plus command bar; the sidebar becomes a drawer under 960 px."], ["Lists", "Rows with thumbnail, title, details, and badges."], ["Editing", "Right-hand drawer over the list. Esc or Close goes back; unsaved changes ask first."], ["Requests", "Inbox split view; on phones the list and the message are separate screens."], ["Tabs", "Segmented control for rate types and request statuses."]],
    tokens: {
      light: { canvas: "#fbfbfa", surface: "#ffffff", "surface-2": "#f4f4f2", "surface-hover": "#f0f0ee", selected: "#e3f3ef", "field-bg": "#ffffff", border: "#e6e6e3", "border-strong": "#7e848e", "card-line": "#e6e6e3", text: "#1d2025", "text-2": "#4a515c", "text-3": "#5f6672", link: "#0b6b62",
        primary: "#0f766e", "primary-hover": "#115e59", "on-primary": "#ffffff", "primary-soft": "#e3f3ef", "primary-soft-text": "#0b5a53", focus: "#0f766e",
        danger: "#c53030", "on-danger": "#ffffff", "danger-soft": "#fdeeee", "danger-text": "#a31b1b", "success-soft": "#e7f5ec", "success-text": "#1c6a39", "warning-soft": "#fdf3df", "warning-text": "#7d4c00", "info-soft": "#e9f0fb", "info-text": "#1d4c8c",
        accent: "#f5b100", "accent-soft": "#fff1cc", "accent-text": "#674800", "accent-ink": "#2b1d00",
        "nav-bg": "#f5f5f3", "nav-text": "#262a31", "nav-muted": "#5f6672", "nav-hover": "#ebebe8", "nav-active": "#ffffff", "nav-active-text": "#0b5a53", "nav-indicator": "#0f766e", "nav-line": "#e6e6e3",
        "logo-bg": "#0f766e", "logo-ink": "#ffffff", "topbar-bg": "#fbfbfa", "warning-dot": "#d48806", overlay: "rgba(20,22,26,.4)",
        "shadow-1": "0 1px 2px rgba(16,24,40,.05), 0 1px 3px rgba(16,24,40,.07)", "shadow-2": "0 6px 16px -4px rgba(16,24,40,.12), 0 2px 4px rgba(16,24,40,.05)", "shadow-3": "0 24px 48px -12px rgba(16,24,40,.25)" },
      dark: { canvas: "#111214", surface: "#18191c", "surface-2": "#1f2024", "surface-hover": "#232428", selected: "#12302c", "field-bg": "#18191c", border: "#2a2c31", "border-strong": "#7b818c", "card-line": "#2a2c31", text: "#ecedee", "text-2": "#b4b8bf", "text-3": "#959ba5", link: "#5fd4c4",
        primary: "#2dd4bf", "primary-hover": "#5eead4", "on-primary": "#04201d", "primary-soft": "#11302c", "primary-soft-text": "#7ee8d9", focus: "#5eead4",
        danger: "#f87171", "on-danger": "#2a0909", "danger-soft": "#3a1717", "danger-text": "#fca5a5", "success-soft": "#102a1a", "success-text": "#86efac", "warning-soft": "#33240a", "warning-text": "#fcd34d", "info-soft": "#13223a", "info-text": "#93c5fd",
        accent: "#fbbf24", "accent-soft": "#33280a", "accent-text": "#fde68a", "accent-ink": "#2b1d00",
        "nav-bg": "#141518", "nav-text": "#d4d6da", "nav-muted": "#959ba5", "nav-hover": "#1d1e22", "nav-active": "#26282d", "nav-active-text": "#ffffff", "nav-indicator": "#2dd4bf", "nav-line": "#2a2c31",
        "logo-bg": "#2dd4bf", "logo-ink": "#04201d", "topbar-bg": "#111214", "warning-dot": "#fbbf24", overlay: "rgba(0,0,0,.6)",
        "shadow-1": "0 1px 2px rgba(0,0,0,.4)", "shadow-2": "0 8px 20px -6px rgba(0,0,0,.6)", "shadow-3": "0 24px 48px -12px rgba(0,0,0,.7)" },
      hc: hc("#00544c", { "nav-bg": "#ffffff", "nav-text": "#000000", "nav-muted": "#1a1a1a", "nav-hover": "#e4e4e4", "nav-active": "#000000", "nav-active-text": "#ffffff", "nav-indicator": "#ffffff", "nav-line": "#000000", "logo-bg": "#000000", "logo-ink": "#ffffff" }),
    },
  },
  {
    id: "summit", file: "3-summit.html", name: "Summit", tagline: "Travel brand", num: 3,
    fonts: "family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500",
    shell: "top", list: "grid", edit: "preview", requests: "board", palette: true, hero: true,
    inspiration: "Material Design 3 and Airbnb",
    summary: "A warm, photo-first office in the Travel With Moeen colors: navy top bar with gold pills, big rounded tiles, a request board, and editors that show a live preview of the website card as you type.",
    traits: ["Navy top bar with gold pill for the current page; a bottom tab bar on phones.", "Tours, places, and posts show as large photo cards, like the public site.", "Every editor has a live preview of how the card looks on the website.", "Requests are a board with New, In progress, and Closed columns.", "Pill buttons, filter-chip tabs, 16 to 28 px corners, Plus Jakarta Sans."],
    principles: [["Look like the brand", "Staff see the navy and gold the guests see, so the office feels like the same company."], ["See the result", "The preview shows the website card while you edit."], ["Big and friendly", "44 px controls and pill buttons are easy on a phone between calls."], ["Status at a glance", "The board shows every request's stage without opening it."]],
    fontNote: "Plus Jakarta Sans from 400 to 800. Bold display headings, 600 labels and buttons.",
    shapeNote: "Pills for buttons, chips, and badges. 20 px cards, 28 px dialogs and hero. Tonal surfaces with soft shadows.",
    type: [["Hero · 700 34/40", "font:700 34px/40px var(--font-display);letter-spacing:-.02em", "Good morning"], ["Page title · 700 30/38", "font:700 30px/38px var(--font-display);letter-spacing:-.02em", "Tours"], ["Card title · 700 17/26", "font:700 17px/26px var(--font-display)", "Day plan"], ["Body · 400 14/22", "font:400 14px/22px var(--font)", "A 5-day air trip to Skardu Valley, with hotel stays and a private driver."], ["Label · 600 14/20", "font:600 14px/20px var(--font)", "Twin room rate"], ["Stat · 800 28/36", "font:800 28px/36px var(--font-display)", "Rs 140,400"]],
    patterns: [["Navigation", "Top bar with six pills and More; a bottom tab bar with four items and More on phones."], ["Lists", "Photo cards in a responsive grid."], ["Editing", "Full page with a live website preview beside the form (above it on small screens)."], ["Requests", "Board of three status columns; a card opens a side panel."], ["Tabs", "Filter chips with a check mark on the chosen one."]],
    tokens: {
      light: { canvas: "#f7f5f0", surface: "#ffffff", "surface-2": "#f0ece3", "surface-hover": "#f1ede4", selected: "#fff1c7", "field-bg": "#ffffff", border: "#e6e0d4", "border-strong": "#7a7466", "card-line": "#e6e0d4", text: "#1b1c1f", "text-2": "#4a4a50", "text-3": "#5f5f66", link: "#1d4f91",
        primary: "#183a63", "primary-hover": "#102a4a", "on-primary": "#ffffff", "primary-soft": "#e1eaf6", "primary-soft-text": "#183a63", focus: "#1d4f91",
        danger: "#b3261e", "on-danger": "#ffffff", "danger-soft": "#f9dedc", "danger-text": "#8c1d18", "success-soft": "#dcefdc", "success-text": "#1d5b2b", "warning-soft": "#fdecc8", "warning-text": "#6b4700", "info-soft": "#e1eaf6", "info-text": "#183a63",
        accent: "#ffb700", "accent-soft": "#ffe8a8", "accent-text": "#3d2900", "accent-ink": "#2b1d00",
        "nav-bg": "#183a63", "nav-text": "#eef3fa", "nav-muted": "#b4c6de", "nav-hover": "#22497a", "nav-active": "#ffb700", "nav-active-text": "#2b1d00", "nav-indicator": "#ffb700", "nav-line": "#22497a",
        "logo-bg": "#ffb700", "logo-ink": "#2b1d00", "topbar-bg": "#183a63", "warning-dot": "#e09a00", overlay: "rgba(16,24,40,.5)",
        "shadow-1": "0 1px 3px rgba(24,58,99,.10), 0 1px 2px rgba(24,58,99,.06)", "shadow-2": "0 10px 24px -8px rgba(24,58,99,.25)", "shadow-3": "0 28px 56px -16px rgba(24,58,99,.35)" },
      dark: { canvas: "#121316", surface: "#1b1c20", "surface-2": "#24252a", "surface-hover": "#2a2b30", selected: "#3a2f12", "field-bg": "#1b1c20", border: "#34353b", "border-strong": "#8b8d96", "card-line": "#34353b", text: "#eceae4", "text-2": "#c3c2bc", "text-3": "#a3a29c", link: "#a9c7ff",
        primary: "#a9c7ff", "primary-hover": "#c8dbff", "on-primary": "#0a2546", "primary-soft": "#1f3350", "primary-soft-text": "#cfe0ff", focus: "#ffcb52",
        danger: "#ffb4ab", "on-danger": "#561e19", "danger-soft": "#3b1814", "danger-text": "#ffb4ab", "success-soft": "#13301a", "success-text": "#9bd8a4", "warning-soft": "#3a2c06", "warning-text": "#ffd479", "info-soft": "#1f3350", "info-text": "#cfe0ff",
        accent: "#ffb700", "accent-soft": "#3a2c06", "accent-text": "#ffd479", "accent-ink": "#2b1d00",
        "nav-bg": "#0e1f36", "nav-text": "#dbe5f3", "nav-muted": "#9fb3cf", "nav-hover": "#17304f", "nav-active": "#ffb700", "nav-active-text": "#2b1d00", "nav-indicator": "#ffb700", "nav-line": "#17304f",
        "logo-bg": "#ffb700", "logo-ink": "#2b1d00", "topbar-bg": "#0e1f36", "warning-dot": "#ffb700", overlay: "rgba(0,0,0,.6)",
        "shadow-1": "0 1px 3px rgba(0,0,0,.4)", "shadow-2": "0 10px 24px -8px rgba(0,0,0,.6)", "shadow-3": "0 28px 56px -16px rgba(0,0,0,.7)" },
      hc: hc("#0d2a4d"),
    },
  },
];

/* ------------------------------------------------------------------ */
/* Contrast check: every version, every theme                          */
/* ------------------------------------------------------------------ */
const PAIRS = [
  ["Body text", "text", "surface", 4.5], ["Body text on canvas", "text", "canvas", 4.5], ["Secondary text", "text-2", "surface", 4.5], ["Secondary text on canvas", "text-2", "canvas", 4.5],
  ["Meta text", "text-3", "surface", 4.5], ["Meta text on sunken", "text-3", "surface-2", 4.5], ["Link", "link", "surface", 4.5], ["Text in a field", "text", "field-bg", 4.5], ["Placeholder", "text-3", "field-bg", 4.5],
  ["Primary button label", "on-primary", "primary", 4.5], ["Primary button hover", "on-primary", "primary-hover", 4.5], ["Danger button label", "on-danger", "danger", 4.5],
  ["Danger text", "danger-text", "surface", 4.5], ["Error on red tint", "danger-text", "danger-soft", 4.5], ["Success badge", "success-text", "success-soft", 4.5], ["Warning badge", "warning-text", "warning-soft", 4.5],
  ["Info badge", "info-text", "info-soft", 4.5], ["Featured badge", "accent-text", "accent-soft", 4.5], ["Count bubble", "accent-ink", "accent", 4.5], ["Selected row", "text", "selected", 4.5], ["Soft primary", "primary-soft-text", "primary-soft", 4.5],
  ["Nav link", "nav-text", "nav-bg", 4.5], ["Nav section label", "nav-muted", "nav-bg", 4.5], ["Nav current page", "nav-active-text", "nav-active", 4.5], ["Logo", "logo-ink", "logo-bg", 4.5],
  ["Field outline", "border-strong", "surface", 3], ["Field outline on field", "border-strong", "field-bg", 3], ["Focus ring", "focus", "surface", 3], ["Focus ring on canvas", "focus", "canvas", 3],
  ["Checked control", "primary", "surface", 3], ["Danger outline", "danger", "surface", 3], ["Star rating", "accent-text", "surface", 3],
];
const lum = (h) => { const m = h.replace("#", ""); return [0, 2, 4].map((i) => parseInt(m.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)).reduce((a, v, i) => a + v * [0.2126, 0.7152, 0.0722][i], 0); };
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05); };
let failures = 0;
for (const v of VERSIONS) for (const [t, tok] of Object.entries(v.tokens)) {
  const ok = PAIRS.filter(([n, f, b, need]) => {
    if (!tok[f] || !tok[b]) { console.log(`MISSING ${v.id}/${t}: ${f} or ${b}`); failures++; return false; }
    const r = ratio(tok[f], tok[b]);
    if (r < need) { console.log(`FAIL ${v.id}/${t}: ${n} ${f} on ${b} = ${r.toFixed(2)} (needs ${need})`); failures++; return false; }
    return true;
  }).length;
  console.log(`${v.name.padEnd(7)} ${t.padEnd(5)} ${ok}/${PAIRS.length}`);
}
if (failures) { console.error(`\n${failures} contrast problems. Nothing written.`); process.exit(1); }

/* ------------------------------------------------------------------ */
/* Write files                                                          */
/* ------------------------------------------------------------------ */
const block = (o) => Object.entries(o).map(([k, val]) => `  --${k}: ${val};`).join("\n");
const themeCss = (v) => [
  `:root {\n${block(v.tokens.light)}\n  color-scheme: light;\n}`,
  `@media (prefers-color-scheme: dark) {\n  :root:not([data-theme="light"]):not([data-theme="hc"]) {\n${block(v.tokens.dark).replace(/^/gm, "  ")}\n    color-scheme: dark;\n  }\n}`,
  `@media (prefers-contrast: more) {\n  :root:not([data-theme]) {\n${block(v.tokens.hc).replace(/^/gm, "  ")}\n  }\n}`,
  `:root[data-theme="dark"] {\n${block(v.tokens.dark)}\n  color-scheme: dark;\n}`,
  `:root[data-theme="hc"] {\n${block(v.tokens.hc)}\n  color-scheme: light;\n}`,
].join("\n");
const js = (o) => JSON.stringify(o).replace(/</g, "\\u003c");
const base = read("base.css"), engine = [read("core.js"), read("screens.js"), read("app.js")].join("\n");

for (const v of VERSIONS) {
  const tcss = themeCss(v);
  const cfg = { ...v, tokens: undefined, others: VERSIONS.filter((o) => o.id !== v.id).map((o) => [`${o.num} · ${o.name}`, o.file]).concat([["All versions", "index.html"]]) };
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${v.name} · Office prototype</title>
<meta name="description" content="Version ${v.num} of the Travel With Moeen office design: ${v.tagline}. A clickable prototype with its design system.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?${v.fonts}&display=swap" rel="stylesheet">
<style>
${tcss}
${base}
${read(`${v.id}.css`)}
</style>
</head>
<body>
<div id="app"></div>
<div id="toasts" class="toasts"></div>
<div id="dlg-root"></div>
<div id="pal-root"></div>
<noscript><p style="padding:24px">This prototype needs JavaScript.</p></noscript>
<script>window.VERSION=${js(cfg)};window.TWM_SEED=${js(seed)};window.CONTRAST_PAIRS=${js(PAIRS)};window.TOKEN_CSS=${js(tcss)};</script>
<script>
${engine}
</script>
</body>
</html>
`;
  writeFileSync(join(OUT, v.file), html);
  console.log(`wrote ${v.file} (${Math.round(html.length / 1024)} KB)`);
}

/* Comparison page */
const card = (v) => {
  const L = v.tokens.light;
  const mock = v.shell === "top"
    ? `<div class="mk" style="background:${L.canvas}"><div class="mk-top" style="background:${L["nav-bg"]}"><i style="background:${L["logo-bg"]}"></i><b style="background:${L["nav-active"]}"></b><b style="background:${L["nav-muted"]};opacity:.5"></b><b style="background:${L["nav-muted"]};opacity:.5"></b></div><div class="mk-grid">${[0, 1, 2, 3, 4, 5].map((i) => `<span style="background:linear-gradient(160deg,${["#ffcf8b,#f08a5d", "#9be7ff,#3f7fd8", "#b7e4a3,#3f8f5a", "#c3b6ff,#6d7fe0", "#a8edea,#4f9fb8", "#ffd77a,#e0732e"][i]});border-radius:${10}px"></span>`).join("")}</div></div>`
    : `<div class="mk mk-side" style="background:${L.canvas}"><div class="mk-nav" style="background:${L["nav-bg"]};${v.id === "meadow" ? `border-right:1px solid ${L.border}` : ""}"><i style="background:${L["logo-bg"]}"></i>${[1, 2, 3, 4, 5, 6].map((i) => `<b style="background:${i === 2 ? L["nav-active"] : L["nav-muted"]};opacity:${i === 2 ? 1 : 0.45};${v.id === "meadow" && i === 2 ? "box-shadow:0 1px 3px rgba(0,0,0,.15)" : ""}"></b>`).join("")}</div><div class="mk-main">${v.id === "harbor" ? `<div class="mk-tbl" style="background:${L.surface}">${[0, 1, 2, 3, 4, 5].map((i) => `<s style="background:${i === 0 ? L["surface-3"] : L.surface};border-bottom:1px solid ${L.border}"></s>`).join("")}</div>` : `<div class="mk-rows" style="background:${L.surface};border-radius:8px">${[0, 1, 2, 3].map(() => `<s><u style="background:linear-gradient(160deg,#9be7ff,#3f7fd8)"></u><em style="background:${L["text-3"]}"></em></s>`).join("")}</div><div class="mk-drawer" style="background:${L.surface};border-left:1px solid ${L.border}"><em style="background:${L["border-strong"]}"></em><em style="background:${L["border-strong"]}"></em><b style="background:${L.primary}"></b></div>`}</div></div>`;
  return `<article class="v"><a class="v-link" href="${v.file}">${mock}<div class="v-body"><p class="v-num">Version ${v.num}</p><h2>${v.name} <span>· ${v.tagline}</span></h2><p>${v.summary}</p></div></a>
    <ul class="v-traits">${v.traits.map((t) => `<li>${t}</li>`).join("")}</ul>
    <div class="v-actions"><a class="btn" href="${v.file}">Open ${v.name}</a><a class="btn ghost" href="${v.file}#/system">Design system</a></div></article>`;
};
const rows = [["Inspired by", (v) => v.inspiration], ["Navigation", (v) => (v.shell === "top" ? "Navy top bar, bottom tabs on phones" : v.id === "meadow" ? "Light sidebar + Ctrl K command bar" : "Dark navy sidebar and header")], ["Lists", (v) => ({ table: "Data tables", rows: "Rows with thumbnails", grid: "Photo cards" }[v.list])], ["Editing", (v) => ({ page: "Full page with breadcrumb", drawer: "Drawer beside the list", preview: "Page with live website preview" }[v.edit])], ["Requests", (v) => ({ table: "Table, then a detail page", inbox: "Inbox split view", board: "Board by status" }[v.requests])], ["Shape", (v) => ({ harbor: "Square, flat, no shadows", meadow: "8–16 px corners, soft shadows", summit: "Pills and 20–28 px corners" }[v.id])], ["Type", (v) => ({ harbor: "IBM Plex Sans", meadow: "Inter", summit: "Plus Jakarta Sans" }[v.id])], ["Brand color", (v) => ({ harbor: "Carbon blue on navy", meadow: "Teal", summit: "Navy and gold" }[v.id])], ["Best for", (v) => ({ harbor: "Rates and long tables; a Manager at a desk", meadow: "Fast editing across many records; keyboard users", summit: "Content and photos; staff on phones" }[v.id])]];
const index = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Office Design Versions</title>
<meta name="description" content="Three design directions for the Travel With Moeen office, each a clickable prototype with its own design system.">
<style>
:root { --bg:#f6f5f2; --panel:#fff; --ink:#1b1c1f; --muted:#55585f; --line:#e3e0d8; --accent:#183a63; --on:#fff; color-scheme: light; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { --bg:#121316; --panel:#1b1c20; --ink:#eceae4; --muted:#b4b3ad; --line:#34353b; --accent:#a9c7ff; --on:#0a2546; color-scheme: dark; } }
:root[data-theme="dark"] { --bg:#121316; --panel:#1b1c20; --ink:#eceae4; --muted:#b4b3ad; --line:#34353b; --accent:#a9c7ff; --on:#0a2546; color-scheme: dark; }
* { box-sizing: border-box; } body { margin:0; background:var(--bg); color:var(--ink); font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
main { max-width:1240px; margin:0 auto; padding:40px 24px 80px; }
h1 { font-size:34px; line-height:1.15; margin:0 0 10px; letter-spacing:-.02em; } .lede { color:var(--muted); max-width:72ch; margin:0; }
.grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:18px; margin-top:28px; }
.v { background:var(--panel); border:1px solid var(--line); border-radius:16px; overflow:hidden; display:flex; flex-direction:column; }
.v-link { color:inherit; text-decoration:none; display:block; } .v-link:hover h2 { text-decoration:underline; }
.v-body { padding:16px 18px 4px; } .v-num { margin:0; font-size:12px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; color:var(--accent); }
.v h2 { margin:2px 0 6px; font-size:22px; } .v h2 span { font-weight:400; color:var(--muted); font-size:16px; } .v-body p:last-child { color:var(--muted); margin:0; font-size:14px; }
.v-traits { margin:10px 18px; padding-left:18px; color:var(--muted); font-size:14px; flex:1; } .v-traits li { margin:4px 0; }
.v-actions { display:flex; gap:8px; padding:0 18px 18px; flex-wrap:wrap; }
.btn { display:inline-flex; align-items:center; min-height:40px; padding:0 16px; border-radius:8px; background:var(--accent); color:var(--on); text-decoration:none; font-weight:600; font-size:14px; }
.btn.ghost { background:transparent; color:var(--ink); border:1px solid var(--muted); }
a:focus-visible { outline:2px solid var(--accent); outline-offset:2px; }
.mk { height:190px; padding:0; display:flex; flex-direction:column; border-bottom:1px solid var(--line); }
.mk-top { height:30px; display:flex; gap:6px; align-items:center; padding:0 10px; } .mk-top i { width:16px; height:16px; border-radius:5px; } .mk-top b { width:40px; height:12px; border-radius:99px; }
.mk-grid { flex:1; display:grid; grid-template-columns:repeat(3,1fr); gap:10px; padding:12px; }
.mk-side { flex-direction:row; } .mk-nav { width:28%; padding:10px 8px; display:grid; gap:6px; align-content:start; } .mk-nav i { width:16px; height:16px; border-radius:4px; margin-bottom:6px; } .mk-nav b { height:9px; border-radius:3px; }
.mk-main { flex:1; padding:12px; display:flex; gap:8px; } .mk-tbl { flex:1; display:grid; } .mk-tbl s { display:block; }
.mk-rows { flex:1; padding:6px; display:grid; gap:6px; align-content:start; } .mk-rows s { display:flex; gap:6px; align-items:center; } .mk-rows u { width:22px; height:16px; border-radius:4px; } .mk-rows em { height:6px; flex:1; border-radius:3px; opacity:.5; }
.mk-drawer { width:42%; padding:8px; display:grid; gap:8px; align-content:start; } .mk-drawer em { height:14px; border:1px solid; border-radius:4px; background:transparent!important; } .mk-drawer b { height:14px; width:50%; border-radius:4px; }
h2.sec { margin:48px 0 10px; font-size:22px; }
.tw { overflow-x:auto; } table { width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--line); border-radius:12px; overflow:hidden; font-size:14px; }
th, td { text-align:left; padding:10px 14px; border-bottom:1px solid var(--line); vertical-align:top; } thead th { background:var(--bg); font-size:13px; color:var(--muted); } tbody th { font-weight:600; width:16%; }
.same { margin-top:16px; color:var(--muted); font-size:14px; max-width:80ch; }
@media (max-width:980px) { .grid { grid-template-columns:1fr; } }
</style></head>
<body><main>
<h1>Office design: three versions</h1>
<p class="lede">Three directions for the Travel With Moeen office at /office. Each one is a clickable prototype of every office screen, with its own design system page. Click any menu item, open a tour, place, or post, edit and save, change a request status, or switch role and theme in the black bar at the top. Changes stay in your browser until you press Reset demo.</p>
<div class="grid">${VERSIONS.map(card).join("")}</div>
<h2 class="sec">Side by side</h2>
<div class="tw"><table><thead><tr><th scope="col"></th>${VERSIONS.map((v) => `<th scope="col">${v.num} · ${v.name}</th>`).join("")}</tr></thead><tbody>
${rows.map(([l, f]) => `<tr><th scope="row">${l}</th>${VERSIONS.map((v) => `<td>${f(v)}</td>`).join("")}</tr>`).join("")}
</tbody></table></div>
<p class="same"><b>Same in all three:</b> the roles and rights in lib/auth/permissions.ts; the save rules in lib/rates.ts (blank, negative, and non-numeric amounts refused); JPEG, PNG, or WebP uploads of 5 MB or less, checked by file signature; confirm dialogs for deleting a tour, removing a login, and changing a role; undo for photos, reviews, slides, and requests; Light, Dark, and High contrast themes that pass WCAG 2.2 AA contrast; keyboard use, visible focus, and phone layouts. Names, phone numbers, and amounts are samples.</p>
</main></body></html>
`;
writeFileSync(join(OUT, "index.html"), index);
console.log("wrote index.html");
